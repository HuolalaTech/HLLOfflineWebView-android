window.onload=function ()
        {
            var oDiv1=document.getElementById("div1");
            var oUl=document.getElementById("ul1");
            var oImg=oDiv1.getElementsByTagName("img");
            oUl.innerHTML=oUl.innerHTML+oUl.innerHTML;
        
           var speed=1;
          
            setInterval(function () {
                if(oUl.offsetLeft<-800)
                {
                    oUl.style.left=0;
                }
                if(oUl.offsetLeft>0)
                {
                    oUl.style.left=-800+'px';
                }
                oUl.style.left=oUl.offsetLeft+speed+'px';
            },30)
 
        }